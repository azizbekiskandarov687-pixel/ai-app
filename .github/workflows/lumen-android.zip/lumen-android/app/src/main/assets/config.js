window.LUMEN_CONFIG = {
  apiKey: '__GEMINI_API_KEY__',
  model: 'gemini-2.5-flash'
};
