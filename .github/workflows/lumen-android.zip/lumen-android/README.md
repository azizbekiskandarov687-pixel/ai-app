# Agent Lumen — Android ilova

Shaxsiy AI yordamchi (Google Gemini bilan). Birinchi ochilganda foydalanuvchidan so‘raydi:
ismi, kasbi, nima kerakligi, gaplashish uslubi, asosiy maqsadi va uyg‘onish vaqti.
Keyin shu ma’lumotlar bo‘yicha o‘zbek tilida suhbatlashadi.

## APK ni GitHub'da yig‘ish

1. GitHub'da yangi repository oching (masalan `lumen-agent`).
2. Shu papkadagi **barcha fayllarni** (yashirin `.github` papkasi bilan) repository'ga yuklang.
   Eng ishonchlisi — kompyuterda `git` bilan push qilish:
   ```
   git init && git add . && git commit -m "Agent Lumen" && git branch -M main
   git remote add origin https://github.com/SIZNING_NOM/lumen-agent.git
   git push -u origin main
   ```
3. (Ixtiyoriy) Kalitni ilovaga o‘rnatib qo‘yish uchun: **Settings → Secrets and variables → Actions →
   New repository secret** → nomi `GEMINI_API_KEY`, qiymati — Google AI Studio kaliti.
   Kalit qo‘ymasangiz, ilovaning o‘zi foydalanuvchidan kalit so‘raydi.
4. **Actions** bo‘limiga o‘ting → **Build APK** → **Run workflow**.
5. 3–6 daqiqadan keyin ish tugagach, ichiga kiring va pastdagi **Artifacts → AgentLumen-apk** ni yuklab oling.
6. ZIP ichidan `app-debug.apk` ni oling, telefonga o‘tkazing va o‘rnating
   (Android "Noma’lum manbalardan o‘rnatishga ruxsat" so‘raydi).

## Google API kaliti

Bepul kalit: https://aistudio.google.com/app/apikey

Muhim: kalitni `GEMINI_API_KEY` secret orqali APK ichiga qo‘ysangiz, APK'ni olgan odam kalitni ajratib olishi mumkin.
Ommaga tarqatmoqchi bo‘lsangiz, kalitni qo‘ymang — har bir foydalanuvchi o‘z kalitini kiritsin,
yoki kalitni Google AI Studio'da cheklab qo‘ying.

## Model nomi

Standart model `gemini-2.5-flash` (`app/src/main/assets/config.js`). Google modellarni yangilab turadi:
agar "Model topilmadi" xatosi chiqsa, ilova Sozlamalarida (⚙) yoki `config.js` da yangi nomni yozing.

## Tuzilishi

- `app/src/main/assets/index.html` — ilovaning butun interfeysi va mantiqi (onboarding, chat, sozlamalar)
- `app/src/main/java/uz/lumen/agent/MainActivity.java` — WebView qobig‘i
- `.github/workflows/build-apk.yml` — APK yig‘uvchi workflow
